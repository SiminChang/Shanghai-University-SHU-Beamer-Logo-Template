# Shanghai University Beamer Logo Template

Compile SHU_BeamerTemplate.tex with XeLaTeX, or run latexmk -xelatex SHU_BeamerTemplate.tex locally.
Edit the standard Beamer title, author, institute and date fields in the main file.
Set the body-fill opacity with `\renewcommand{\SHUblockopacity}{0.70}` after loading the theme.

[Project and documentation](https://github.com/SiminChang/Shanghai-University-SHU-Beamer-Logo-Template)
